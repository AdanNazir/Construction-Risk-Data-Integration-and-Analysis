import os
from elasticsearch import Elasticsearch
from elasticsearch import helpers
from elasticsearch.helpers import BulkIndexError
from dotenv import load_dotenv
from ..CustomException.elastic_exceptions import MissingError

# Load environment variables from the .env file
load_dotenv()

class ElasticSearchManager():
    
    def __new__(cls, *args, **kwargs):
        """
        Singleton pattern for the ElasticSearch class.

        Returns:
        - ElasticSearch: An instance of the ElasticSearch class.
        """
        if not hasattr(cls, '_instance'):
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self,host,port) -> None:
        self.es = Elasticsearch([{'host': host, 'port': port, 'scheme' :'htt'}])

    # def configureation(self) -> None:
    #     # Get the values of host and port from the environment
    #     self.host = os.getenv("host")
    #     self.port = int(os.getenv("port"))  
    #     # Check required variables
    #     if self.host is not None and self.port is not None:
    #         print(f"Host: {self.host}, Port: {self.port}")
    #     else:
    #         raise MissingError("The host and port is missing.")
    
    def check_connection(self) -> None:
        if self.es.ping():
            print("The connections is established with ElasticSearch")
        else:
            raise ConnectionError("Connection with ElasticSearch failed.")
    
    def __doc_generator(self,data_frame, es_index = "CONSTPYSPARK"):
        """
        Generate documents for bulk indexing into Elasticsearch.

        Parameters:
        - data_frame (pandas.DataFrame): The DataFrame containing data to be indexed.
        - es_index (str): The target Elasticsearch index.

        Yields:
        - dict: A document to be indexed.
        """
        for index, row in data_frame.iterrows():
            print(f"Adding {row} to elasticsearch")
            yield {
                "_index": es_index,  # Specify the target Elasticsearch index
                "_source": row.to_dict()  # Convert the row to a dictionary
            }
    def insert_data(self,df):
            success, failed = helpers.bulk(self.es, self.__doc_generator(df, "CONSTPYSPARK"), index="CONSTPYSPARK")
            print(f"Succesffuly entered{success} where as failed to enter {failed}")
            return success, failed
    def retreive_all_data(self):
        query = {
            "query": {
                "term": {
                    "match_all": {}  # Assuming "DISEASE" is a keyword field
                }
            }
        }
        result = self.es.search(index="CONSTPYSPARK", body=query, size=10)
        return result