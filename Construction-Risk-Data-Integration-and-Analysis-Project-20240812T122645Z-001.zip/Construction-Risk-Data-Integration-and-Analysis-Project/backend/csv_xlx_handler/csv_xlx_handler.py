import pandas
import pyspark

class csv_xlx_handling():
    def __init__(self, df) -> None:
        self.df = df
    
    def metadeta(self) -> None:
        # Show the data in Spark dataframe
        print("The data is: ",self.df.show())
        #Check the Schema
        print("The schema of our dataframe is: " ,self.df.printSchema())
        #Check Dtypes
        print("The dtypes of our data is: ",self.df.dtypes)
        #Get the description of data
        print("The description of our data is: ",self.df.describe().show())
    
