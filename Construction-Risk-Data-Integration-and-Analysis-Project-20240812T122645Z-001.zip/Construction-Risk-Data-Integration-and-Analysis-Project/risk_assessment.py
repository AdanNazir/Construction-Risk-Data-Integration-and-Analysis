import streamlit as st
import pandas as pd
from elasticsearch import Elasticsearch
import spacy
from sklearn.metrics.pairwise import cosine_similarity
from elasticsearch.helpers import scan


nlp = spacy.load("en_core_web_md")
# Connect to Elasticsearch
es_client = Elasticsearch([{'host': 'localhost', 'port': 9200}])
#es_client.indices.delete(index='_all')

st.header("Construction Risk Assessment Data Integration and Analysis ")


st.sidebar.markdown("""
    <style>
    .sidebar .sidebar-content {
        background-color: #f0f2f6;
        border-radius: 20px;
        padding: 20px;
        font-size: 18px;
        font-family: Arial, sans-serif;
        color: #333;
    }
    .sidebar .sidebar-content button {
        display: block;
        padding: 10px 20px;
        margin-bottom: 10px;
        border-radius: 10px;
        text-decoration: none;
        transition: background-color 0.3s, box-shadow 0.3s;
        background-color: transparent;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        border: none;
        cursor: pointer;
    }
    .sidebar .sidebar-content button:hover {
        background-color: rgba(255, 255, 255, 0.2);
        backdrop-filter: blur(10px);
    }
    </style>
    """, unsafe_allow_html=True)

# Main function for ingestion
def ingestion():
    st.title("Data Ingestion")
    
    # Dropdown menu for category selection
    category = st.selectbox("Select Category", ["general", "civil", "arch", "mech", "equip"])
    
    # Upload CSV file
    uploaded_file = st.file_uploader("Upload CSV file", type=["csv"])
    
    if uploaded_file is not None and category is not None:
        # Index name based on category
        index_name = f"{category.replace(' ', '_')}_indexer"
        
        # Read the CSV file into a DataFrame
        df = pd.read_csv(uploaded_file, delimiter=',')
        df.dropna(subset=[" Identify Hazards", "Hazard Controls or Precautions"], inplace=True)
        df = df[[" Identify Hazards", "Hazard Controls or Precautions"]]

        if ' No.' in df.columns:
            df.drop(columns=[' No.'], inplace=True)
        for column in df.columns:
            df[column]=df[column].astype(str)
        
            
        # Check if index exists
        if not es_client.indices.exists(index=index_name):
            field_limit = 100000 if category in ["mech", "arch"] else 10000
            index_settings = {
                "settings": {
                    "index.mapping.total_fields.limit": field_limit
                }
            }
            es_client.indices.create(index=index_name, body=index_settings)
        
        # Index the DataFrame into Elasticsearch
        df_dict = df.to_dict(orient="records")
        for idx, doc in enumerate(df_dict):
            print("Row fetched: ",idx)
            es_client.index(index=index_name, id=idx, body=doc)
        
        # Display success message
        st.success("CSV file uploaded and indexed successfully!")

def create_index(index_name):
    es_client.indices.create(index=index_name)

def index_dataframe(df, index_name):
    df_dict = df.to_dict(orient="records")
    for idx, doc in enumerate(df_dict):
        es_client.index(index=index_name, id=idx, body=doc)

def index_exists(index_name):
    return es_client.indices.exists(index=index_name)

# Function to perform fuzzy search on WBS2 dataframe
def elastic_fuzzy_search_wbs2(es_client, key_sentence):
    tokens = key_sentence.split()  # Split the sentence into tokens
    
    # Build a boolean query with a "should" clause for each token in the prompt
    should_clauses = []
    for token in tokens:
        should_clauses.extend([
            {"wildcard": {" Construction industry_by type of work_name of work type": {"value": f"*{token}*", "boost": 1.0}}},
            {"wildcard": {" Construction industry_Detailed process name by type of work": {"value": f"*{token}*", "boost": 1.0}}}
        ])
    
    query = {
        "query": {
            "bool": {
                "should": should_clauses
            }
        },
        "size": 10000  # Specify the number of hits to retrieve
    }
    
    # Execute the search query
    response = es_client.search(index='wbs', body=query)
    
    # Extract matched entries
    matched_entries = []
    for hit in response["hits"]["hits"]:
        matched_entries.append(hit["_source"])
    
    return pd.DataFrame(matched_entries)

# Main function for retrieval
def retrieval():
    st.title("Data Retrieval")
    
    # Dropdown menu for category selection
    category = st.selectbox("Select Category", ["general", "civil", "arch", "mech", "equip"])
    
    # Ask user to input the text for fuzzy matching
    prompt = st.text_input("Enter text for fuzzy matching:")
    
    if prompt != "" and category is not None:
        # Index name based on category
        index_name = f"{category.replace(' ', '_')}_indexer"
        
        # Submit button for fuzzy search
        if st.button("Submit"):
            # Perform fuzzy search using Elasticsearch
            elastic_fuzzy_search(es_client, index_name, prompt)
            
            
            df1 = pd.read_csv("WBS_2.csv", delimiter=',')
            if not index_exists('wbs'):
                
                create_index('wbs')
        
        # Index the DataFrame into Elasticsearch
            index_dataframe(df1,'wbs')
            res_df2=elastic_fuzzy_search_wbs2(es_client,prompt)
            st.write("### Matched WBS2 Entries:")
            st.dataframe(res_df2)  # Display all rows

# Function to perform fuzzy search using Elasticsearch
def elastic_fuzzy_search(es_client, index_name, key_sentence):
    tokens = key_sentence.split()  # Split the sentence into tokens
    
    # Build a boolean query with a "should" clause for each token in the prompt
    should_clauses = []
    for token in tokens:
        should_clauses.extend([
            {"wildcard": {" Identify Hazards": {"value": f"*{token}*", "boost": 1.0}}},
            {"wildcard": {"Hazard Controls or Precautions": {"value": f"*{token}*", "boost": 1.0}}}
        ])
    
    query = {
        "query": {
            "bool": {
                "should": should_clauses
            }
        },
        "size": 10000 # Limit to a smaller number of hits initially
    }
    
    # Execute the search query
    response = es_client.search(index=index_name, body=query)
    
    # Extract matched entries
    matched_entries = []
    for hit in response["hits"]["hits"]:
        matched_entries.append({
            " Identify Hazards": hit["_source"][" Identify Hazards"],
            "Hazard Controls or Precautions": hit["_source"]["Hazard Controls or Precautions"]
        })
    remaining_rows=[]
    # Get remaining rows not returned by Elasticsearch fuzzy search
    scan_query = {
    "query": {
        "match_all": {}
    }
}

# Use the scan helper to fetch all documents
    scroll_documents = scan(es_client, index=index_name, query=scan_query, size=10000)

# Extract documents from the scroll result
    all_documents = [hit["_source"] for hit in scroll_documents]
    remaining_rows = [doc for doc in all_documents if doc not in matched_entries]
    st.write("### ElasticSearch Analysis:")
    st.write(pd.DataFrame(matched_entries))
    #print(len(remaining_rows))
    # Add code here to fetch all rows from Elasticsearch based on your index
    
    #print(remaining_rows)
    # Process the keyword prompt with spaCy
    keyword_doc = nlp(key_sentence)
    nlp_rows=[]
    temp=""
# Iterate over remaining rows
    for row in remaining_rows:
        temp=row[" Identify Hazards"]
        temp=temp.split(" ")
        
        if len(temp)==1:
            
            continue
        # Process row with spaCy
        row_doc = nlp(row[" Identify Hazards"] + " " + row["Hazard Controls or Precautions"])

        # Calculate cosine similarity
        similarity_score = cosine_similarity(keyword_doc.vector.reshape(1, -1), row_doc.vector.reshape(1, -1))[0][0]
        
        # If similarity score is above threshold, consider the row relevant
        if similarity_score > 0.60:
            #print(similarity_score)
            nlp_rows.append({" Identify Hazards": row[" Identify Hazards"], 
                                    "Hazard Controls or Precautions": row["Hazard Controls or Precautions"]})
    
    st.write("Nlp Analysis: ")
    df1= pd.DataFrame(nlp_rows)
    mask = ~df1.isin(pd.DataFrame(matched_entries).to_dict(orient='list')).all(1)

# Filter rows in df1 not present in df2
    updated_nlp_df = df1[mask].reset_index(drop=True)
    st.write(updated_nlp_df)
    



# Main function to switch between ingestion and retrieval
def main():
    page = st.sidebar.radio("Go to:", ("Ingestion", "Retrieval"))

    if page == "Ingestion":
        ingestion()
    elif page == "Retrieval":
        retrieval()

if __name__ == "__main__":
    main()