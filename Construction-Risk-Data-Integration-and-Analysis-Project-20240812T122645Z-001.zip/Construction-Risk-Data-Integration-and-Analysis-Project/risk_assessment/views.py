from django.shortcuts import render, redirect
from django.http import HttpResponse
from .forms import UploadFileForm, SearchForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView
from django.urls import reverse_lazy
import pandas as pd
from elasticsearch import Elasticsearch
import spacy
from django.contrib.auth import authenticate, login
from django.urls import reverse
from sklearn.metrics.pairwise import cosine_similarity
from elasticsearch.helpers import scan
from transformers import AutoModel, AutoTokenizer
import torch
#nlp = spacy.load("ko_core_news_md")  # Load the Korean language model for spaCy
es_client = Elasticsearch([{'host': 'localhost', 'port': 9200}])
tokenizer = AutoTokenizer.from_pretrained("lassl/bert-ko-small")
model = AutoModel.from_pretrained("lassl/bert-ko-small")


def CustomLoginView(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect(reverse('ingestion'))
        else:
            return render(request, 'risk_assessment/login.html', {'error': 'Invalid credentials'})
    return render(request, 'risk_assessment/login.html')


@login_required
def ingestion(request):
    success_message = ''
    if request.method == 'POST':
        form = UploadFileForm(request.POST, request.FILES)
        if form.is_valid():
            category = form.cleaned_data['category']
            uploaded_file = request.FILES['file']
            df = pd.read_csv(uploaded_file, delimiter=',')

            # Determine the column names based on the index name
            index_name = f"{category.replace(' ', '_')}_indexer"
            #print(index_name)
            if index_name == 'wbs2_indexer':
                print("HELLOOOO")
                hazard_column = ' 건설업_직종별_직종명'
                precaution_column = ' 건설업_공종별 세부 공정명'
            else:
                hazard_column = " 위험 식별"  # Example Korean column name for "Identify Hazards"
                precaution_column = " 위험 통제 또는 예방조치"  # Example Korean column name for "Hazard Controls or Precautions"
            
            df.dropna(subset=[hazard_column, precaution_column], inplace=True)
            df = df[[hazard_column, precaution_column]]

            # Create the index with appropriate settings and mappings
            field_limit = 100000 if category in ["mech", "arch"] else 10000
            index_settings = {
                "settings": {
                    "index.mapping.total_fields.limit": field_limit,
                    "analysis": {
                        "analyzer": {
                            "korean_analyzer": {
                                "type": "custom",
                                "tokenizer": "nori_tokenizer"
                            }
                        }
                    }
                },
                "mappings": {
                    "properties": {
                        hazard_column: {
                            "type": "text",
                            "analyzer": "korean_analyzer"
                        },
                        precaution_column: {
                            "type": "text",
                            "analyzer": "korean_analyzer"
                        }
                    }
                }
            }
            es_client.indices.create(index=index_name, body=index_settings, ignore=400)  # ignore 400 to avoid error if index already exists

            # Index the data
            df_dict = df.to_dict(orient="records")
            for idx, doc in enumerate(df_dict):
                es_client.index(index=index_name, id=idx, body=doc)

            success_message = 'File uploaded and indexed successfully!'

    else:
        form = UploadFileForm()
    return render(request, 'risk_assessment/ingestion.html', {'form': form, 'success_message': success_message})


@login_required
def retrieval(request):
    if request.method == 'POST':
        form = SearchForm(request.POST)
        if form.is_valid():
            prompt = form.cleaned_data['prompt']
            category = form.cleaned_data['category']
            index_name = f"{category.replace(' ', '_')}_indexer"
            matched_entries = elastic_fuzzy_search(es_client, index_name, prompt, language='korean')
            remaining_rows=[]
            # Get remaining rows not returned by Elasticsearch fuzzy search
            scan_query = {
            "query": {
                "match_all": {}
            }
            }

        # Use the scan helper to fetch all documents
            scroll_documents = scan(es_client, index=index_name, query=scan_query, size=10000)

        # Extract documents from the scroll result
            all_documents = [hit["_source"] for hit in scroll_documents]
            remaining_rows = [doc for doc in all_documents if doc not in matched_entries]
            df_matched_entries = pd.DataFrame(matched_entries)
            df_matched_entries=df_matched_entries.drop_duplicates()


            matched_entries_html = df_matched_entries.to_html(classes='table table-responsive table-striped table-hover', index=False, border=0, header=True)

            nlp_results = nlp_analysis(remaining_rows, prompt,model,tokenizer)
            nlp_results_html = nlp_results.to_html(classes='table table-responsive table-striped table-hover', index=False, border=0, header=True)


            # Search in WBS2 index
            res_df_wbs2 = elastic_fuzzy_search_wbs2(es_client, prompt)
            #print(res_df_wbs2)
            wbs2_html = pd.DataFrame(res_df_wbs2).to_html(classes='table table-responsive table-striped table-hover', index=False, border=0, header=True)

            combined_data = pd.concat([df_matched_entries, nlp_results, pd.DataFrame(res_df_wbs2)])

            # Convert the DataFrame to a CSV file and save it temporarily
            csv_file_path = 'temp_data.csv'
            combined_data.to_csv(csv_file_path, index=False, encoding='utf-8-sig')

            # Pass the URL for downloading the CSV file to the template
            download_url = reverse('download_csv') + f'?prompt={prompt}&category={category}'

            return render(request, 'risk_assessment/results.html', {
                'matched_entries_html': matched_entries_html,
                'nlp_results_html': nlp_results_html,
                'wbs2_html': wbs2_html,
                'download_url': download_url
            })

    
    form = SearchForm()
    return render(request, 'risk_assessment/retrieval.html', {'form': form})


def download_csv(request):
    prompt = request.GET.get('prompt', 'default_prompt')
    category = request.GET.get('category', 'default_category')
    print(prompt,category)
    file_name = f"{prompt}_{category}.csv"

    csv_file_path = 'temp_data.csv'
    with open(csv_file_path, 'rb') as csv_file:
        response = HttpResponse(csv_file, content_type='text/csv; charset=utf-8-sig')
        response['Content-Disposition'] = f'attachment; filename="{file_name}"'
        return response


def elastic_fuzzy_search_wbs2(es_client, key_sentence):
    tokens = key_sentence.split()  # Split the sentence into tokens
    
    # Build a boolean query with a "should" clause for each token in the prompt
    should_clauses = []
    for token in tokens:
        should_clauses.extend([
        {"fuzzy": {' 건설업_직종별_직종명': {"value": token, "fuzziness": "AUTO"}}},
        {"fuzzy": {' 건설업_공종별 세부 공정명': {"value": token, "fuzziness": "AUTO"}}}
    ])
    
    query = {
        "query": {
            "bool": {
                "should": should_clauses
            }
        },
        "size": 10000  # Specify the number of hits to retrieve
    }
    
    # Execute the search query
    response = es_client.search(index='wbs2', body=query)
    
    # Extract matched entries
    matched_entries = []
    for hit in response["hits"]["hits"]:
        matched_entries.append(hit["_source"])
    
    return pd.DataFrame(matched_entries)

def elastic_fuzzy_search(es_client, index_name, key_sentence, language):
    tokens = key_sentence.split()
    should_clauses = []
    for token in tokens:
        if language == 'korean':
            should_clauses.extend([
            {"fuzzy": {" 위험 식별": {"value": token, "fuzziness": "AUTO"}}},
            {"fuzzy": {" 위험 통제 또는 예방조치": {"value": token, "fuzziness": "AUTO"}}}
        ])
        else:
            should_clauses.extend([
                {"match": {"Identify Hazards": token}},
                {"match": {"Hazard Controls or Precautions": token}}
            ])
    query = {
        "query": {
            "bool": {
                "should": should_clauses
            }
        },
        "size": 10000
    }
    response = es_client.search(index=index_name, body=query)
    matched_entries = [hit["_source"] for hit in response["hits"]["hits"]]
    return matched_entries

def nlp_analysis(matched_entries, prompt,model,tokenizer):
    #keyword_doc = nlp(prompt)
    prompt_encoding = tokenizer(prompt, return_tensors='pt', padding=True, truncation=True)
    prompt_output = model(**prompt_encoding)
    prompt_embedding = prompt_output.last_hidden_state.mean(dim=1).detach().numpy()
    nlp_rows = []
    temp=""
# Iterate over remaining rows
    for row in matched_entries:
        temp=row[" 위험 식별"]
        temp=temp.split(" ")
        
        if len(temp)==1:
            
            continue
        # Process row with spaCy
        row_doc = row[" 위험 식별"] + " " + row[" 위험 통제 또는 예방조치"]
        row_encoding = tokenizer(row_doc, return_tensors='pt', padding=True, truncation=True)
        row_output = model(**row_encoding)
        row_embedding = row_output.last_hidden_state.mean(dim=1).detach().numpy()

        similarity_score = cosine_similarity(prompt_embedding, row_embedding)[0][0]

        # Calculate cosine similarity
        #similarity_score = cosine_similarity(keyword_doc.vector.reshape(1, -1), row_doc.vector.reshape(1, -1))[0][0]
        print(similarity_score)
        # If similarity score is above threshold, consider the row relevant
        if similarity_score > 0.55:
            #print(similarity_score)
            nlp_rows.append({" 위험 식별": row[" 위험 식별"], 
                                    "위험 통제 또는 예방조치": row[" 위험 통제 또는 예방조치"]})

    df1 = pd.DataFrame(nlp_rows)
    df1 = df1.drop_duplicates()
    return df1

def success(request):
    return HttpResponse('File uploaded and indexed successfully!')








 
