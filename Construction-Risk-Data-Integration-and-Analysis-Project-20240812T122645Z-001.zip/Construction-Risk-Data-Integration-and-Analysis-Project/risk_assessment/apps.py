from django.apps import AppConfig


class RiskAssessmentConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'risk_assessment'
