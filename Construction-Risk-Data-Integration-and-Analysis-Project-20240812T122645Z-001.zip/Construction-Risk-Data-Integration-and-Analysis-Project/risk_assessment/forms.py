from django import forms

class UploadFileForm(forms.Form):
    category = forms.ChoiceField(choices=[('general', 'General'), ('civil', 'Civil'), ('arch', 'Architectural'), ('mech', 'Mechanical'), ('equip', 'Equipment'),('wbs2','WBS')])
    file = forms.FileField()

class SearchForm(forms.Form):
    category = forms.ChoiceField(choices=[('general', 'General'), ('civil', 'Civil'), ('arch', 'Architectural'), ('mech', 'Mechanical'), ('equip', 'Equipment')])
    prompt = forms.CharField(max_length=1000)
