from django.urls import path
from .views import CustomLoginView, ingestion, retrieval,download_csv
from django.contrib.auth.views import LogoutView

urlpatterns = [
    path('login/', CustomLoginView, name='login'),
    path('logout/', LogoutView.as_view(next_page='login'), name='logout'),
    path('download_csv/', download_csv, name='download_csv'),
    path('ingestion/', ingestion, name='ingestion'),
    path('retrieval/', retrieval, name='retrieval'),
]
