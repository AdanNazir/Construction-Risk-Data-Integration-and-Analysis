from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('risk_assessment/', include('risk_assessment.urls')),  # Include the URLs from the risk_assessment app
]
